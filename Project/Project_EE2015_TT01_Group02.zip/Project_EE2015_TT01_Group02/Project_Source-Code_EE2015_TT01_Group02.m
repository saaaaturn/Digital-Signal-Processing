% MATLAB Program for FIR and IIR Filter Design

% Clear workspace and close all figures
clc; clear; close all;

%% FIR Filter Design (Lowpass, Highpass, Bandpass, Bandstop)
fs = 8000;   % Sampling frequency in Hz
N = 50;      % Filter order (number of coefficients - 1)

% FIR Lowpass Filter
fc_lp = 1000; % Cutoff frequency in Hz (lowpass)
wc_lp = 2 * fc_lp / fs; % Normalized cutoff frequency
b_lp = fir1(N, wc_lp, 'low', hamming(N + 1));

figure;
freqz(b_lp, 1, 1024, fs);
title('Frequency Response of FIR Lowpass Filter');

% FIR Highpass Filter
fc_hp = 1000; % Cutoff frequency in Hz (highpass)
wc_hp = 2 * fc_hp / fs; % Normalized cutoff frequency
b_hp = fir1(N, wc_hp, 'high', hamming(N + 1));

figure;
freqz(b_hp, 1, 1024, fs);
title('Frequency Response of FIR Highpass Filter');

% FIR Bandpass Filter
fc1_bp = 1000; % Lower cutoff frequency in Hz
fc2_bp = 2000; % Upper cutoff frequency in Hz
wc_bp = [2 * fc1_bp / fs, 2 * fc2_bp / fs]; % Normalized cutoff frequencies
b_bp = fir1(N, wc_bp, 'bandpass', hamming(N + 1));

figure;
freqz(b_bp, 1, 1024, fs);
title('Frequency Response of FIR Bandpass Filter');

% FIR Bandstop Filter
fc1_bs = 1000; % Lower stopband frequency in Hz
fc2_bs = 2000; % Upper stopband frequency in Hz
wc_bs = [2 * fc1_bs / fs, 2 * fc2_bs / fs]; % Normalized cutoff frequencies
b_bs = fir1(N, wc_bs, 'stop', hamming(N + 1));

figure;
freqz(b_bs, 1, 1024, fs);
title('Frequency Response of FIR Bandstop Filter');

%% IIR Filter Design (Lowpass, Highpass, Bandpass, Bandstop)
fs = 8000; % Sampling frequency in Hz
N = 4;     % Filter order

% IIR Lowpass Filter
fc_lp_iir = 1000; % Cutoff frequency in Hz
[b_lp_iir, a_lp_iir] = butter(N, 2 * fc_lp_iir / fs, 'low');

figure;
freqz(b_lp_iir, a_lp_iir, 1024, fs);
title('Frequency Response of IIR Lowpass Filter');

% IIR Highpass Filter
fc_hp_iir = 1000; % Cutoff frequency in Hz
[b_hp_iir, a_hp_iir] = butter(N, 2 * fc_hp_iir / fs, 'high');

figure;
freqz(b_hp_iir, a_hp_iir, 1024, fs);
title('Frequency Response of IIR Highpass Filter');

% IIR Bandpass Filter
fc1_bp_iir = 1000; % Lower cutoff frequency in Hz
fc2_bp_iir = 2000; % Upper cutoff frequency in Hz
wc_bp_iir = [2 * fc1_bp_iir / fs, 2 * fc2_bp_iir / fs]; % Normalized cutoff frequencies
[b_bp_iir, a_bp_iir] = butter(N, wc_bp_iir, 'bandpass');

figure;
freqz(b_bp_iir, a_bp_iir, 1024, fs);
title('Frequency Response of IIR Bandpass Filter');

% IIR Bandstop Filter
fc1_bs_iir = 1000; % Lower stopband frequency in Hz
fc2_bs_iir = 2000; % Upper stopband frequency in Hz
wc_bs_iir = [2 * fc1_bs_iir / fs, 2 * fc2_bs_iir / fs]; % Normalized cutoff frequencies
[b_bs_iir, a_bs_iir] = butter(N, wc_bs_iir, 'stop');

figure;
freqz(b_bs_iir, a_bs_iir, 1024, fs);
title('Frequency Response of IIR Bandstop Filter');

%% Export Filter Coefficients
% Export coefficients for hardware implementation
save('FIR_Lowpass_Coeffs.txt', 'b_lp', '-ascii');
save('FIR_Highpass_Coeffs.txt', 'b_hp', '-ascii');
save('FIR_Bandpass_Coeffs.txt', 'b_bp', '-ascii');
save('FIR_Bandstop_Coeffs.txt', 'b_bs', '-ascii');
save('IIR_Lowpass_Coeffs.txt', 'b_lp_iir', '-ascii');
save('IIR_Highpass_Coeffs.txt', 'b_hp_iir', '-ascii');
save('IIR_Bandpass_Coeffs.txt', 'b_bp_iir', '-ascii');
save('IIR_Bandstop_Coeffs.txt', 'b_bs_iir', '-ascii');

%% Summary
% This program demonstrates the design of FIR and IIR filters (lowpass, highpass, bandpass, and bandstop).
% Coefficients are exported for potential hardware implementation.
